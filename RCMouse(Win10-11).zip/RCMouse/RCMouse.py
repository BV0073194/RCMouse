import subprocess
import importlib.util
from flask import Flask, render_template, request
import pyautogui

app = Flask(__name__)

# List of required libraries
required_libraries = [
    'flask',
    'pyautogui',
    'qrcode[pil]'
]

# Install missing libraries
for lib in required_libraries:
    try:
        importlib.util.find_spec(lib)
        print(f"{lib} is already installed")
    except ImportError:
        print(f"Installing {lib}...")
        subprocess.check_call(['py', '-3.9', '-m', 'pip', 'install', lib])
        print(f"Successfully installed {lib}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/move_mouse', methods=['POST'])
def move_mouse():
    try:
        # Receive joystick movement data
        data = request.get_json()
        x = data.get('x', 0)
        y = data.get('y', 0)

        # Calculate movement intensity for both x and y directions
        intensity_x = x * abs(x)
        intensity_y = y * abs(y)

        # Scale mouse movement based on intensity
        speed_factor = 5  # Adjust the base speed factor as needed
        move_x = int(intensity_x * speed_factor)
        move_y = int(intensity_y * speed_factor)

        # Get screen size
        screen_width, screen_height = pyautogui.size()

        # Get current mouse position
        current_x, current_y = pyautogui.position()

        # Calculate new mouse position, ensuring it stays away from screen corners
        new_x = min(max(1, current_x + move_x), screen_width - 2)
        new_y = min(max(1, current_y + move_y), screen_height - 2)

        # Move mouse cursor
        pyautogui.moveTo(new_x, new_y)

        # Print mouse coordinates to console
        print(f"Mouse moved to: ({new_x}, {new_y})")
        return 'OK'
    except Exception as e:
        print(f"Error: {e}")
        return 'An error occurred', 500

@app.route('/left_click', methods=['POST'])
def left_click():
    # Check if PyAutoGUI is installed
    if importlib.util.find_spec('pyautogui'):
        # Perform a left mouse click
        pyautogui.click(button='left')
        return 'OK'
    else:
        return 'PyAutoGUI is not installed', 500

@app.route('/right_click', methods=['POST'])
def right_click():
    # Check if PyAutoGUI is installed
    if importlib.util.find_spec('pyautogui'):
        # Perform a right mouse click
        pyautogui.click(button='right')
        return 'OK'
    else:
        return 'PyAutoGUI is not installed', 500

@app.route('/reset_mouse', methods=['POST'])
def reset_mouse():
    try:
        # Get screen size
        screen_width, screen_height = pyautogui.size()

        # Calculate center coordinates
        center_x = screen_width // 2
        center_y = screen_height // 2

        # Move mouse cursor to the center of the screen
        pyautogui.moveTo(center_x, center_y)

        # Print mouse coordinates to console
        print(f"Mouse reset to center: ({center_x}, {center_y})")
        return 'OK'
    except Exception as e:
        print(f"Error: {e}")
        return 'An error occurred', 500

@app.route('/type_keys', methods=['POST'])
def type_keys():
    try:
        data = request.get_json()
        key = data.get('key', '')
        if key == 'delete':
            pyautogui.press('backspace')  # Simulate pressing the backspace key
        elif key == 'return':  # Handle the return key
            pyautogui.press('enter')  # Simulate pressing the enter key
        else:
            pyautogui.typewrite(key)  # Simulate typing the received key
        return 'OK'
    except Exception as e:
        print(f"Error: {e}")
        return 'An error occurred', 500

if __name__ == '__main__':
    app.run(debug=True)
