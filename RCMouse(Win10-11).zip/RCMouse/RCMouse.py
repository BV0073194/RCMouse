import importlib.util
import subprocess
import logging
import atexit

def install_libraries(required_libraries):
    for lib in required_libraries:
        try:
            importlib.util.find_spec(lib)
            print(f"{lib} is already installed")
        except ImportError:
            print(f"Installing {lib}...")
            subprocess.check_call(['pip3.9', 'install', lib])
            print(f"Successfully installed {lib}")

# List of required libraries
required_libraries = [
    'flask',
    'pyautogui',
    'qrcode[pil]'
]

# Install missing libraries
install_libraries(required_libraries)

from flask import Flask, render_template, request
import pyautogui

app = Flask(__name__)

# Function to start ngrok in the background
def start_ngrok():
    subprocess.Popen(['ngrok', 'http', '5000'])

# Start ngrok in the background
start_ngrok()

# Function to stop ngrok
def stop_ngrok():
    # Define the command to terminate ngrok
    command = 'taskkill /f /im ngrok.exe'
    # Execute the command
    subprocess.run(command, shell=True)

# Register stop_ngrok function to be called on exit
atexit.register(stop_ngrok)

# Disable Werkzeug logging to reduce console output
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

# Pre-calculate screen size
screen_width, screen_height = pyautogui.size()

# Function to start ngrok in the background
def start_ngrok():
    subprocess.Popen(['ngrok', 'http', '5000'])

# Start ngrok in the background
start_ngrok()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/move_mouse', methods=['POST'])
def move_mouse():
    try:
        data = request.get_json()
        x, y = data.get('x', 0), data.get('y', 0)

        # Scale mouse movement based on intensity
        speed_factor = 5
        move_x = int(x * abs(x) * speed_factor)
        move_y = int(y * abs(y) * speed_factor)

        # Calculate new mouse position
        new_x = min(max(1, pyautogui.position()[0] + move_x), screen_width - 2)
        new_y = min(max(1, pyautogui.position()[1] + move_y), screen_height - 2)

        # Move mouse cursor
        pyautogui.moveTo(new_x, new_y)
        return 'OK'
    except Exception as e:
        return f'Error: {e}', 500

@app.route('/left_click', methods=['POST'])
def left_click():
    try:
        pyautogui.click(button='left')
        return 'OK'
    except Exception as e:
        return f'Error: {e}', 500

@app.route('/right_click', methods=['POST'])
def right_click():
    try:
        pyautogui.click(button='right')
        return 'OK'
    except Exception as e:
        return f'Error: {e}', 500

@app.route('/reset_mouse', methods=['POST'])
def reset_mouse():
    try:
        # Move mouse cursor to the center of the screen
        pyautogui.moveTo(screen_width // 2, screen_height // 2)
        return 'OK'
    except Exception as e:
        return f'Error: {e}', 500

@app.route('/type_keys', methods=['POST'])
def type_keys():
    try:
        data = request.get_json()
        key = data.get('key', '')
        if key == 'delete':
            pyautogui.press('backspace')
        elif key == 'return':
            pyautogui.press('enter')
        else:
            pyautogui.typewrite(key)
        return 'OK'
    except Exception as e:
        return f'Error: {e}', 500

if __name__ == '__main__':
    app.run(debug=False)
